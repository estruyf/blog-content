﻿function Mylinks_Dialog(siteURL, Title, URL) {
    var options = {
        title: "Add to My Links",
        showClose: true,
        allowMaximize: false,
        autoSize: true,
        url: siteURL + '/_layouts/estruyf.mylinks/estruyf.QuickLinksDialog.aspx?Title=' + Title + '&URL=' + URL
    };
    SP.UI.ModalDialog.showModalDialog(options);
}