var clientContext = null;
var web = null
//Set your task list name here
var ListName = "My to-do List"


/*
*
* openDialog function: this function opens a modal dialog with a custom HTML form.
*
*/
function openDialog() {	
	//Create todo item input form
	var htmlContent = document.createElement("div");
	htmlContent.id = "AddToDo";
	htmlContent.className = "todo";
	htmlContent.setAttribute("style", "padding: 10px;");
	htmlContent.innerHTML = '<h2>Add a new to-do item.</h2>';
	htmlContent.innerHTML += '<label class="desc" id="lbl_Title" for="todo_Title">To-Do</label>';
	htmlContent.innerHTML += '<div><input id="todo_Title" name="todo_Title" type="text" class="" value="" maxlength="255" /></div>';
	htmlContent.innerHTML += '<label class="desc" id="lbl_Desc" for="todo_Desc">Description</label>';
	htmlContent.innerHTML += '<div><textarea id="todo_Desc" name="todo_Desc" class="" rows="10" cols="50" tabindex="2" onkeyup="" ></textarea></div>';
	htmlContent.innerHTML += '<input type="submit" onmousedown="AddToDoItem();" value="Submit" class="submit" name="addItem" id="addItem">';
	
    var options = {
		html: htmlContent,
        title: "Create a new todo item.",
        showClose: true,
        allowMaximize: false,
        autoSize: true,
        dialogReturnValueCallback: DialogCallback
    };
	//Open dialog window
    dlg = SP.UI.ModalDialog.showModalDialog(options);
}
/*
*
* AddToDoItem function: this function will add a new item to the task list.
*
*/
function AddToDoItem() {
	//Retrieve the input values
	var itemTitle = $("#todo_Title").val();
	var itemDesc = $("#todo_Desc").val();
	//Check if the title field is filled in
	if(itemTitle.length > 0) {
		//Get the current SP context
		clientContext = new SP.ClientContext.get_current();
		web = clientContext.get_web();
		
		var list = web.get_lists().getByTitle(ListName);
			
		var itemCreateInfo = new SP.ListItemCreationInformation();
		this.listItem = list.addItem(itemCreateInfo);
		
		//Item Title
		listItem.set_item('Title', itemTitle);
		//Item Description
		listItem.set_item('Body', itemDesc);
		//Set Status to In Progress
		listItem.set_item('Status', 'In Progress');
			
		listItem.update();
		
		clientContext.load(listItem);
		clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceeded), Function.createDelegate(this, this.onQueryFailed));
	}
	else {
		alert("Fill in the title field");
	}
}
/*
*
* AddToDoItem delegate functions
*
*/
function onQuerySucceeded() {
	SP.UI.ModalDialog.commonModalDialogClose(SP.UI.DialogResult.OK,'To-do Item Created');
}
function onQueryFailed(sender, args) {
	SP.UI.ModalDialog.commonModalDialogClose(SP.UI.DialogResult.cancel, 'To-do Item Creation Failed: ' + args.get_message());
}
/*
*
* DialogCallback function: this function is called when the dialog window is closed.
*
*/
function DialogCallback(result, returnedMessage) {
	//Check if the message length is larger than zero
	if(returnedMessage.length > 0 && returnedMessage != null)
	{
		//Show notification message
		SP.UI.Notify.addNotification(returnedMessage, false);
		Initialize();
	}
}

/*
*
* Initialize function: fill up the "In Progess" and "Completed" list.
*
*/
ExecuteOrDelayUntilScriptLoaded(Initialize, "sp.js");

//Retrieve all the task items
function Initialize() {
    //Get the current SP context
    clientContext = new SP.ClientContext.get_current();
    web = clientContext.get_web();
    //Set the correct list
    var list = web.get_lists().getByTitle(ListName);
	
	//Add the "In Progress" items to the list
	var camlQuery = new SP.CamlQuery();
	//Retrieve only the items where the "Status" is equal to "In Progress"
    var q = "<View><Query><Where><Eq><FieldRef Name='Status' /><Value Type='Choice'>In Progress</Value></Eq></Where></Query></View>";
    camlQuery.set_viewXml(q);
    this.listItems = list.getItems(camlQuery);
    //Only retrieve the "ID", "Title" fields.
    clientContext.load(listItems, 'Include(ID, Title)');
	
	//Add the latest "Completed" items to the list
	var camlCompleteQuery = new SP.CamlQuery();
	//Retrieve only the items where the "Status" is equal to "Completed" and show only the top 5
    var q = "<View><Query><Where><Eq><FieldRef Name='Status' /><Value Type='Choice'>Completed</Value></Eq></Where><OrderBy><FieldRef Name='Modified' Ascending='False' /></OrderBy></Query><RowLimit>5</RowLimit></View>";
    camlCompleteQuery.set_viewXml(q);
    this.listCompleteItems = list.getItems(camlCompleteQuery);
    //Only retrieve the "ID", "Title" fields.
    clientContext.load(listCompleteItems, 'Include(ID, Title)');
    //Execute the listitem query
    clientContext.executeQueryAsync(Function.createDelegate(this, this.onListItemsLoadSuccess), Function.createDelegate(this, this.onListItemsLoadFailed));
}

/*
*
* Initialize delegate function: this function adds the returned items to the HTML lists.
*
*/
function onListItemsLoadSuccess(sender, args) {
	//Add the "In Progress" list items
	//Remove current list items 
	$('#todo_items ul li').remove();
    var listEnumerator = this.listItems.getEnumerator();
    //Iterate though all of the items
    while (listEnumerator.moveNext()) {
        //Retrieve the current list item
        var oListItem = listEnumerator.get_current();
		//Add the items to the list
		var itemHtml = "<li ref='" + oListItem.get_item('ID') + "'>";
			itemHtml += "<a href='#' title='Mark as completed' onClick='javascript:MarkAsComplete(" + oListItem.get_item('ID') + "); return false;'><img src='/_layouts/images/CHECK.GIF' /></a>";
			itemHtml += "<a href='#' title='Delete to-do item' onClick='javascript:DeleteItem(" + oListItem.get_item('ID') + "); return false;'><img src='/_layouts/images/delete.GIF' /></a>";
			itemHtml += oListItem.get_item('Title') + "</li>";
		$("#todo_items ul").append(itemHtml);
    }
	
	//Add the "Completed" list items
	//Remove current list items 
	$('#todo_completed ul li').remove();
    listEnumerator = this.listCompleteItems.getEnumerator();
    //Iterate though all of the items
    while (listEnumerator.moveNext()) {
        //Retrieve the current list item
        var oListItem = listEnumerator.get_current();
		//Add the items to the list
		$("#todo_completed ul").append("<li ref='" + oListItem.get_item('ID') + "'>" + oListItem.get_item('Title') + "</li>");
    }
}
function onListItemsLoadFailed(sender, args) {
	SP.UI.Notify.addNotification("List items load failed: " + args.get_message(), false);
}

/*
*
* MarkAsComplete function: this function will set the item status to "Completed"
*
*/
function MarkAsComplete(itemID) {
	clientContext = new SP.ClientContext.get_current();
    web = clientContext.get_web();
    var list = web.get_lists().getByTitle(ListName);

    this.listItem = list.getItemById(itemID);

    //Set the new status
    listItem.set_item('Status', 'Completed');

    listItem.update();
    clientContext.load(listItem);
    //Execute the query
    clientContext.executeQueryAsync(Function.createDelegate(this, this.onUpdateSucceeded), Function.createDelegate(this, this.onUpdateFailed));
}
/*
*
* DeleteItem function: this function deletes the item.
*
*/
function DeleteItem(itemID) {
	clientContext = new SP.ClientContext.get_current();
    web = clientContext.get_web();
    var list = web.get_lists().getByTitle(ListName);
	
	this.listItem = list.getItemById(itemID);
	listItem.deleteObject();
	
	clientContext.executeQueryAsync(Function.createDelegate(this, this.onUpdateSucceeded), Function.createDelegate(this, this.onUpdateFailed));
}
/*
*
* Delegate functions that are used by the "DeleteItem" and "MarkAsComplete" function.
*
*/
function onUpdateSucceeded() {
	SP.UI.Notify.addNotification("To-do Item Updated", false);
	Initialize();
}
function onUpdateFailed() {
	SP.UI.Notify.addNotification("To-do Item Updated Failed: " + args.get_message(), false);
}
