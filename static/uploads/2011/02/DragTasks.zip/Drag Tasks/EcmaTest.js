/// <reference name="MicrosoftAjax.js" />
/// <reference path="file://C:/Program Files/Common Files/Microsoft Shared/Web Server Extensions/14/TEMPLATE/LAYOUTS/SP.UI.Dialog.debug" />
/// <reference path="file://C:/Program Files/Common Files/Microsoft Shared/Web Server Extensions/14/TEMPLATE/LAYOUTS/SP.core.debug.js" />
/// <reference path="file://C:/Program Files/Common Files/Microsoft Shared/Web Server Extensions/14/TEMPLATE/LAYOUTS/SP.debug.js" />
/// <reference path="file://C:/Program Files/Common Files/Microsoft Shared/Web Server Extensions/14/TEMPLATE/LAYOUTS/jquery-1.4.1-vsdoc.js" />

var clientContext = null;
var web = null;
ExecuteOrDelayUntilScriptLoaded(Initialize, "sp.js");

//Retrieve all the task items
function Initialize() {
    //Get the current SP context
    clientContext = new SP.ClientContext.get_current();
    web = clientContext.get_web();
    //Set the correct list
    var list = web.get_lists().getByTitle("Tasks");
    var camlQuery = new SP.CamlQuery();
    var q = "<Where></Where>";
    camlQuery.set_viewXml(q);
    this.listItems = list.getItems(camlQuery);
    //Only retrieve the "ID", "Title" and "Status" fields.
    clientContext.load(listItems, 'Include(ID, Title, Status)');
    //Execute the listitem query
    clientContext.executeQueryAsync(Function.createDelegate(this, this.onListItemsLoadSuccess), Function.createDelegate(this, this.onQueryFailed));
}

//On success, put the task items to the correct list
function onListItemsLoadSuccess(sender, args) {
    var listEnumerator = this.listItems.getEnumerator();
    //Iterate though all of the items
    while (listEnumerator.moveNext()) {
        //Retrieve the current list item
        var oListItem = listEnumerator.get_current();
        var status = oListItem.get_item('Status');

        //Add the items to the correct list
        if (status == "Not Started") {
            $("#notstarted").append("<div class='item' ref='" + oListItem.get_item('ID') + "'>" + oListItem.get_item('Title') + "</div>");
        }
        else if (status == "In Progress") {
            $("#inprogress").append("<div class='item' ref='" + oListItem.get_item('ID') + "'>" + oListItem.get_item('Title') + "</div>");
        }
        else if (status == "Completed") {
            $("#completed").append("<div class='item' ref='" + oListItem.get_item('ID') + "'>" + oListItem.get_item('Title') + "</div>");
        }
    }
}

$(function () {
    //Attach the draggable handler to the task items
    $(".item").liveDraggable({ containment: "#task-blocks", scroll: false });

    //Make it possible to drop items on the status boxes
    $("#notstarted, #inprogress, #completed").droppable({
        drop: function (event, ui) {
            $("<div></div>").attr('class', 'item').attr('ref', ui.draggable.attr('ref')).text(ui.draggable.text()).appendTo(this);
            deleteItem(ui.draggable);
            changeItemToStatus(ui.draggable.attr('ref'), $(this).attr("id"));
        }
    });
});

//Change the moved task item
function changeItemToStatus(itemID, newStatus) {
    clientContext = new SP.ClientContext.get_current();
    web = clientContext.get_web();
    var list = web.get_lists().getByTitle("Tasks");

    this.listItem = list.getItemById(itemID);

    //Set the new status
    if (newStatus == "notstarted") {
        listItem.set_item('Status', 'Not Started');
    }
    else if (newStatus == "inprogress") {
        listItem.set_item('Status', 'In Progress');
    }
    else if (newStatus == "completed") {
        listItem.set_item('Status', 'Completed');
    }

    listItem.update();
    clientContext.load(listItem);
    //Execute the query
    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceeded), Function.createDelegate(this, this.onQueryFailed));
}

//Delete the dropped item when it is placed on a new list.
function deleteItem($item) {
    $item.fadeOut();
}

//This are the jQUery Live plugins.
//This plugin enable you to bind the draggable event to the items that are placed by an Ajax call.
(function ($) {
    jQuery.fn.liveDraggable = function (opts) {
        this.live("mouseover", function () {
            if (!$(this).data("init")) {
                $(this).data("init", true).draggable(opts);
            }
        });
    };
})(jQuery);

//Show an alert if the item is successfully updated.
function onQuerySucceeded() {
    alert('Item updated!');
}
//If the ecmascript failed, output the error in an alert.
function onQueryFailed(sender, args) {
    alert('request failed ' + args.get_message() + '\n' + args.get_stackTrace());
}