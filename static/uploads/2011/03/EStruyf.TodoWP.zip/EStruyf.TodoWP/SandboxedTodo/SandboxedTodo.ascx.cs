﻿using System;
using System.ComponentModel;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Collections;

namespace EStruyf.TodoWP.SandboxedTodo
{
    [ToolboxItem(false)]
    public partial class SandboxedTodo : System.Web.UI.WebControls.WebParts.WebPart
    {
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        #region Custom ASP.NET web part property
        public override object WebBrowsableObject
        {
            get
            {
                return this;
            }
        }

        //Task list name string
        private String _taskList = null;

        [Personalizable(), WebBrowsable()]
        public String taskList
        {
            get { return _taskList; }
            set { _taskList = value; }
        }

        //Create an editor part to set the custom task list
        public override EditorPartCollection CreateEditorParts()
        {
            ArrayList editorArray = new ArrayList();
            CustomProperty edPart = new CustomProperty();
            edPart.ID = this.ID + "_editorPart1";
            editorArray.Add(edPart);
            EditorPartCollection editorParts = new EditorPartCollection(editorArray);
            return editorParts;
        }

        //Create a custom EditorPart to edit the WebPart control.
        private class CustomProperty : EditorPart
        {
            TextBox _tbTaskList;

            public CustomProperty()
            {
                Title = "To-do list settings";
            }

            public override bool ApplyChanges()
            {
                SandboxedTodo part = (SandboxedTodo)WebPartToEdit;
                //Update the custom WebPart control with the task list
                part.taskList = tbTaskList.Text;

                return true;
            }

            public override void SyncChanges()
            {
                SandboxedTodo part = (SandboxedTodo)WebPartToEdit;
                String currentList = part.taskList;
            }

            protected override void CreateChildControls()
            {
                Controls.Clear();

                //Add a new textbox control to set the task list
                _tbTaskList = new TextBox();

                Controls.Add(_tbTaskList);

            }

            protected override void RenderContents(HtmlTextWriter writer)
            {
                writer.Write("<b>Set the to-do list</b>");
                writer.WriteBreak();
                writer.Write("List:");
                writer.WriteBreak();
                _tbTaskList.RenderControl(writer);
                writer.WriteBreak();
            }

            //Return the task list name from the textbox
            private TextBox tbTaskList
            {
                get
                {
                    EnsureChildControls();
                    return _tbTaskList;
                }
            }
        }
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
