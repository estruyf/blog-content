﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Compiler;
using System.IO;
using Microsoft.SharePoint.WorkflowActions;

namespace estruyf.SPDActivity.GetFileExtension
{
    public class GetFileExtension: Activity
    {
        // Fields
        public static DependencyProperty __ContextProperty = DependencyProperty.Register("__Context", typeof(WorkflowContext), typeof(GetFileExtension));
        public static DependencyProperty StringValProperty = DependencyProperty.Register("StringVal", typeof(string), typeof(GetFileExtension));
        public static DependencyProperty SubstringVariableProperty = DependencyProperty.Register("SubstringVariable", typeof(string), typeof(GetFileExtension));

        // Methods
        protected override ActivityExecutionStatus Execute(ActivityExecutionContext executionContext)
        {
            if (this.StringVal == null && this.StringVal == "")
            {
                this.SubstringVariable = string.Empty;
            }
            else
            {
                try
                {
                    this.SubstringVariable = Path.GetExtension(this.StringVal);
                    this.SubstringVariable = this.SubstringVariable.Replace(".", "");
                }
                catch (Exception)
                {
                    this.SubstringVariable = string.Empty;
                }
            }
            return ActivityExecutionStatus.Closed;
        }

        // Properties
        [ValidationOption(ValidationOption.Optional)]
        public WorkflowContext __Context
        {
            get
            {
                return (WorkflowContext)base.GetValue(__ContextProperty);
            }
            set
            {
                base.SetValue(__ContextProperty, value);
            }
        }

        [ValidationOption(ValidationOption.Required)]
        public string StringVal
        {
            get
            {
                return (string)base.GetValue(StringValProperty);
            }
            set
            {
                base.SetValue(StringValProperty, value);
            }
        }

        [ValidationOption(ValidationOption.Required)]
        public string SubstringVariable
        {
            get
            {
                return (string)base.GetValue(SubstringVariableProperty);
            }
            set
            {
                base.SetValue(SubstringVariableProperty, value);
            }
        }
    }
}
