﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;
using Microsoft.Office.Server.Administration;
using Microsoft.Office.Server.Internal.Resources;
using System.Web.UI.WebControls;

namespace estruyf.QuiesceFarm.Layouts.estruyf.QuiesceFarm
{
    public partial class QuiesceFarmPage : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.valQuiesceMinutes.ValidateEmptyText = true;
            //Queisce farm
            SessionStateService sessionStateService = GetSessionStateService();
            if (sessionStateService != null)
            {
                InitializePageControls();
            }
        }

        private void InitializePageControls()
        {
            SessionStateService sessionStateService = GetSessionStateService();

            //Set the Quiescing Label to the currect state
            lblStatus.Text = sessionStateService.QuiesceState.ToString();
            lblStatus.CssClass = sessionStateService.QuiesceState.ToString();

            QuiesceEndTime(sessionStateService);

            switch(sessionStateService.QuiesceState)
            {
                case SessionStateService.QuiesceMode.Normal:
                    //Minutes Textbox
                    tbQuiesceMinutes.Enabled = true;
                    //Quiesce Button
                    btnQuiesceFarm.Enabled = true;
                    btnQuiesceFarm.Visible = true;
                    pnlNormal.Visible = true;
                    //Stop Quiesce Button
                    btnStopQuiesce.Enabled = false;
                    btnStopQuiesce.Visible = false;
                    pnlQuiescing.Visible = false;
                    break;
                case SessionStateService.QuiesceMode.Quiescing:
                    //Minutes Textbox
                    tbQuiesceMinutes.Enabled = false;
                    //Quiesce Button
                    btnQuiesceFarm.Enabled = false;
                    btnQuiesceFarm.Visible = false;
                    pnlNormal.Visible = false;
                    //Stop Quiesce Button
                    btnStopQuiesce.Enabled = true;
                    btnStopQuiesce.Visible = true;
                    pnlQuiescing.Visible = true;
                    break;
                case SessionStateService.QuiesceMode.Quiesced:
                    //Minutes Textbox
                    tbQuiesceMinutes.Enabled = false;
                    //Quiesce Button
                    btnQuiesceFarm.Enabled = false;
                    btnQuiesceFarm.Visible = false;
                    pnlNormal.Visible = false;
                    //Stop Quiesce Button
                    btnStopQuiesce.Enabled = true;
                    btnStopQuiesce.Visible = true;
                    pnlQuiescing.Visible = false;
                    break;
            }
        }

        protected void btnQuiesceFarm_Click(object sender, EventArgs e)
        {
            //Validate the page
            this.Validate();

            StartQuiescing();

            InitializePageControls();
        }

        protected void btnStopQuiesce_Click(object sender, EventArgs e)
        {
            StopQuiescing();

            InitializePageControls();
        }

        private void StartQuiescing()
        {
            SessionStateService sessionStateService = GetSessionStateService();

            if (this.Page.IsValid && sessionStateService != null && sessionStateService.QuiesceState == SessionStateService.QuiesceMode.Normal)
            {
                int minutes = int.Parse(tbQuiesceMinutes.Text);
                sessionStateService.Quiesce(new TimeSpan(0, minutes, 0));
                sessionStateService.Update();
            }
        }

        private void StopQuiescing()
        {
            SessionStateService sessionStateService = GetSessionStateService();

            if (sessionStateService != null && sessionStateService.QuiesceState != SessionStateService.QuiesceMode.Normal)
            {
                sessionStateService.Unquiesce();
                sessionStateService.Update();
            }
        }

        //Write Quiesced time to label
        private void QuiesceEndTime(SessionStateService sessionStateService)
        {
            if (sessionStateService.QuiesceState == SessionStateService.QuiesceMode.Quiescing)
            {
                DateTime dateTime = sessionStateService.QuiesceEndTime();
                lblTime.Text = dateTime.ToString("dd-MM-yyyy HH:mm:ss");
            }
        }

        //Input validation
        protected void InputMinutesValidation(object sender, ServerValidateEventArgs e)
        {
            if (e != null)
            {
                int result = 0;
                if (int.TryParse(e.Value, out result) && result >= 0 && (long)result <= 1440L)
                {
                    e.IsValid = true;
                }
                else
                {
                    e.IsValid = false;
                }
            }
            else 
            {
                e.IsValid = false;
            }
        }

        //Retrieve the farm sessionstate service
        private SessionStateService GetSessionStateService()
        {
            SessionStateService value = SPFarm.Local.Services.GetValue<SessionStateService>(string.Empty);
            return value;
        }
    }
}
